/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tknzer_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/03 13:48:22 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/03 15:22:03 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	print_token(char **token)
{
	int	i;

	printf("\nToken Qty: %i\n", ft_mtx_size(token));
	i = 0;
	while (token[i])
	{
		printf("token[%i]: %s\n", i, token[i]);
		i++;
	}
	printf("-----\n");
}
