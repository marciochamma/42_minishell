/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tknzer_type1.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/05 16:55:36 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/17 16:19:58 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Type 1: Delim = space,  Quotes= SQ / DQ, Operator= <|>

#include "minishell.h"

int	substr_quote1(char *str)
{
	int		len;
	char	quote;

	len = 0;
	quote = str[len++];
	while (str[len] && str[len] != quote)
		len++;
	if (str[len] == quote)
		len++;
	return (len);
}

int	substr_oper1(char *str)
{
	int	len;

	len = 1;
	while (str[len] && str[len] == str[len - 1])
		len++;
	return (len);
}

int	len_tkn1(char *str)
{
	int	len;

	len = 0;
	while (str[len] && str[len] != ' ')
	{
		if (str[len] == '\'' || str[len] == '\"')
			len += substr_quote1(&str[len]);
		else if (ft_strchr("<|>", str[len]))
		{
			if (len)
				break ;
			len += substr_oper1(&str[len]);
			break ;
		}
		else
			len++;
	}
	return (len);
}

int	count_tkn1(char *str)
{
	int		i;
	int		count;

	i = 0;
	count = 0;
	while (str[i])
	{
		while (str[i] == ' ')
			i++;
		if (str[i] != '\0')
			count++;
		i += len_tkn1(&str[i]);
	}
	return (count);
}

char	**tknzer_t1(char *str)
{
	char	**token;
	int		count;
	int		i;
	int		j;

	count = count_tkn1(str);
	token = ft_calloc((count + 1), sizeof(char *));
	if (token == NULL)
		return (NULL);
	i = 0;
	j = 0;
	while (j < count)
	{
		while (str[i] == ' ')
			i++;
		token[j] = ft_calloc(len_tkn1(&str[i]) + 1, sizeof(char));
		if (token[j] == NULL)
			return (NULL);
		ft_strlcpy(token[j], &str[i], len_tkn1(&str[i]) + 1);
		i += len_tkn1(&str[i]);
		j++;
	}
	free(str);
	print_token(token);
	return (token);
}
