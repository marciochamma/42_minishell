/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tknzer_type2.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/23 09:38:34 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/03 15:43:59 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Type 2: Delim = n/a,  Quotes= SQ / DQ, Operator= $

#include "minishell.h"

size_t	substr_quote2(char *str)
{
	size_t	len;
	char	quote;

	len = 0;
	quote = str[len++];
	while (str[len] && str[len] != quote)
		len++;
	if (str[len] == quote)
		len++;
	return (len);
}

size_t	substr_oper2(char *str)
{
	size_t	len;

	len = 1;
	while (str[len] && str[len] == str[len - 1])
		len++;
	return (len);
}

// Only function tkn_parse_len changes comparing to tknzer_ast

int	len_tkn2(char *str)
{
	int	len;

	len = 0;
	while (str[len] && str[len] != ' ')
	{
		if (str[len] == '\'' || str[len] == '\"')
		{
			if (len && str[len - 1] != '$')
				break ;
			len += substr_quote2(&str[len]);
			break ;
		}
		else if (str[len] == '$')
		{
			if (len)
				break ;
			len += substr_oper2(&str[len]);
		}
		else
			len++;
	}
	return (len);
}

int	count_tkn2(char *str)
{
	int		i;
	int		count;

	i = 0;
	count = 0;
	while (str[i])
	{
		while (str[i] == ' ')
			i++;
		if (str[i] != '\0')
			count++;
		i += len_tkn2(&str[i]);
	}
	return (count);
}

char	**tknzer_t2(char *str)
{
	char	**token;
	int		count;
	int		i;
	int		j;

	count = count_tkn2(str);
	token = ft_calloc((count + 1), sizeof(char *));
	if (token == NULL)
		return (NULL);
	i = 0;
	j = 0;
	while (j < count)
	{
		while (str[i] == ' ')
			i++;
		token[j] = ft_calloc(len_tkn2(&str[i]) + 1, sizeof(char));
		if (token[j] == NULL)
			return (NULL);
		ft_strlcpy(token[j], &str[i], len_tkn2(&str[i]) + 1);
		i += len_tkn2(&str[i]);
		j++;
	}
	return (token);
}
