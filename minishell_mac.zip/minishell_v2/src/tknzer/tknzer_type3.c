/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tknzer_type3.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/10 00:37:49 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/11 21:35:32 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char	**tknzer_t3(char *str)
{
	char		**tkn;
	char		*delim_pos;
	size_t		len;

	if (str == NULL)
		return (NULL);
	tkn = ft_calloc(3 + 1, sizeof(char *));
	if (str[0] == '=' || !ft_strchr(str, '='))
	{
		tkn[0] = ft_strdup(str);
		return (tkn);
	}
	delim_pos = ft_strchr(str, '=');
	len = delim_pos - str;
	tkn[0] = ft_calloc((len + 1), sizeof(char));
	ft_strlcpy(tkn[0], str, len + 1);
	tkn[1] = ft_strdup("=");
	tkn[2] = ft_calloc((ft_strlen(delim_pos + 1) + 1), sizeof(char));
	ft_strlcpy(tkn[2], delim_pos + 1, ft_strlen(delim_pos + 1) + 1);
	return (tkn);
}
