/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/24 22:06:41 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/21 22:28:20 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	verification(char *input)
{
	char	quote;
	int		i;

	quote = 0;
	i = 0;
	while (input[i])
	{
		if (input[i] == '\'' || input[i] == '\"')
		{
			if (!quote)
				quote = input[i];
			else if (quote == input[i])
				quote = 0;
		}
		i++;
	}
	if (quote)
		printf("Houston, we have a problem!\n");
	else
		printf("go Forrest\n");
}

void	forced_exit(char *str)
{
	if (!ft_strcmp("x", str))
	{
		free (str);
		exit (EXIT_SUCCESS);
	}
}

int	main(int argc, char **argv, char **envp)
{
	char	*input;
	t_list	*ast;

	(void)argc;
	(void)argv;
	hashtable_load(envp);
	exec1();
	while (42)
	{
		input = readline("$> ");
		if (input)
		{
			add_history(input);
			verification(input);
			forced_exit(input);
			ast = parse_ast(input);
			print_ast(ast);
			exec2(ast);
			input = NULL;
		}
		free_ast_list(ast);
	}
	hashtable_mx(NULL, NULL, FREE);
	return (0);
}
