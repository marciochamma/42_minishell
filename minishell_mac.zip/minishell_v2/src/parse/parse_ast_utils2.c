/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_ast_utils2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/19 11:54:09 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/09 23:59:18 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	free_ast_ctt(t_ctt *ctt)
{
	t_arg	*arg;
	t_arg	*temp_arg;

	arg = ctt->arg;
	while (arg)
	{
		temp_arg = arg;
		arg = arg->next;
		free(temp_arg->str);
		free(temp_arg);
	}
	free(ctt);
}

void	free_ast_list(t_list *list)
{
	t_list	*temp;

	while (list)
	{
		temp = list;
		list = list->next;
		free_ast_ctt((t_ctt *)temp->content);
		free(temp);
	}
}

void	print_arg(t_ctt *ctt)
{
	t_arg	*arg;

	arg = ctt->arg;
	while (arg)
	{
		if (arg->type == CMD)
			printf("%c[%i]: %s\n", arg->type, arg->id, arg->str);
		arg = arg->next;
	}
	arg = ctt->arg;
	while (arg)
	{
		if (arg->type != CMD)
		{
			printf("%c[%i]: %s   ", arg->type, arg->id, arg->str);
			printf("|fd: %i   |mode: %i\n", arg->fd, arg->mode);
		}
		arg = arg->next;
	}
}

void	print_ast(t_list *ast)
{
	t_list	*current;
	t_ctt	*ctt;

	(void)ast;
	printf("\nAst Nodes Qty: %i\n", ft_lstsize(ast));
	current = ast;
	while (current)
	{
		ctt = (t_ctt *)(current->content);
		printf("-----\n");
		printf("Node[%i]: %c\n", ctt->id, ctt->side);
		print_arg(ctt);
		current = current->next;
	}
	printf("-----\n\n");
}
