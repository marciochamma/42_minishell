/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_ast_utils1.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/28 11:25:45 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/09 18:09:48 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char	*arg_expand_replace(char *str, int i)
{
	t_env	*temp;
	char	*temp1;
	char	*temp2;
	int		count;

	count = 0;
	while (ft_isalnum(str[i + 1 + count]) || str[i + 1 + count] == '_')
		count++;
	temp1 = ft_substr(str, i + 1, count);
	temp = hashtable_search(temp1);
	if (temp)
		temp2 = temp->value;
	else
		temp2 = "";
	free(temp1);
	return (ft_substr_insert(str, i, count + 1, temp2));
}

char	*arg_expand(char *str)
{
	char	*temp;
	int		i;

	i = 0;
	while (str[i])
	{
		if (str[i] == '$' && (ft_isalnum(str[i + 1]) || str[i + 1] == '_'
				|| str[i + 1] == '?'))
		{	
			temp = arg_expand_replace(str, i);
			free(str);
			str = ft_strdup(temp);
			i += ft_strlen(temp);
			free(temp);
		}
		else
			i++;
	}
	return (str);
}

char	*arg_trim(char *str, const char *set)
{
	size_t	start;
	size_t	end;
	char	*new;

	start = 0;
	end = ft_strlen(str);
	if (ft_strchr(set, str[start]))
		start++;
	if (ft_strrchr(set, str[end - 1]))
		end--;
	if (start == end)
		end = 1;
	new = ft_calloc((end - start + 1), sizeof(char));
	ft_strlcpy(new, &str[start], end - start + 1);
	return (new);
}

void	arg_conditions(char **tkn, char **mtx)
{
	int		i;

	i = 0;
	while (tkn[i])
	{
		if (tkn[i][0] == '$' && (tkn[i][1] == '\"' || tkn[i][1] == '\''))
			mtx[i] = arg_trim(&tkn[i][1], &tkn[i][1]);
		else if (tkn[i][0] == '\"' || tkn[i][0] == '\'')
			mtx[i] = arg_trim(&tkn[i][0], &tkn[i][0]);
		else
			mtx[i] = ft_strdup(&tkn[i][0]);
		if (tkn[i][0] != '\'')
			mtx[i] = arg_expand(mtx[i]);
		i++;
	}
}

char	*arg_adjust(char *str)
{
	char	**tkn;
	char	**mtx;
	int		i;
	char	*temp;

	tkn = tknzer_t2(str);
	i = ft_mtx_size(tkn);
	mtx = ft_calloc(i + 1, sizeof(char *));
	arg_conditions(tkn, mtx);
	temp = ft_mtxstr(mtx);
	ft_mtx_free(tkn);
	ft_mtx_free(mtx);
	return (temp);
}
