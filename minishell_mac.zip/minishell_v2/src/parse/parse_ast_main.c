/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_ast_main.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/13 16:20:08 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/21 22:28:46 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	ast_add_node(t_list **list)
{
	t_ctt	*ctt;
	t_list	*temp;

	if (*list != NULL)
		ctt = ft_lstlast(*list)->content;
	ctt = ft_calloc(1, sizeof(t_ctt));
	temp = ft_lstnew(ctt);
	ft_lstadd_back(list, temp);
	ctt->id = ft_lstsize(*list) - 1;
	ctt->side = NOPIPE;
}

void	parse_arg_ctt(char *oper, char *type, int *fd, int *mode)
{
	*type = REDIR;
	if (oper[0] == 'C')
		*type = CMD;
	else if (oper[0] == '<')
	{
		*fd = 0;
		if (oper[1] != oper[0])
			*mode = O_RDONLY;
		else if (oper[1] == oper[0])
			*type = HEREDOC;
	}
	else if (oper[0] == '>')
	{
		*fd = 1;
		if (oper[1] != oper[0])
			*mode = O_WRONLY | O_TRUNC | O_CREAT;
		else if (oper[1] == oper[0])
			*mode = O_WRONLY | O_APPEND | O_CREAT;
	}
}

void	parse_arg(t_list **ast, char *token, char *oper)
{
	t_ctt	*ctt;
	t_arg	*new;
	t_arg	*temp;

	ctt = ft_lstlast(*ast)->content;
	temp = ctt->arg;
	new = ft_calloc(1, sizeof(t_arg));
	new->id = 0;
	if (temp == NULL)
		ctt->arg = new;
	else
	{
		while (temp->next != NULL)
			temp = temp->next;
		temp->next = new;
		new->id = temp->id + 1;
	}
	parse_arg_ctt(oper, &new->type, &new->fd, &new->mode);
	new->str = arg_adjust(token);
}

void	parse_pipe(t_list **ast)
{
	t_ctt	*content;

	content = ft_lstlast(*ast)->content;
	content->side = LEFT;
	ast_add_node(ast);
	content = ft_lstlast(*ast)->content;
	content->side = RIGHT;
}

t_list	*parse_ast(char *str)
{
	t_list	*ast;
	char	**token;
	int		i;

	token = tknzer_t1(str);
	ast = NULL;
	ast_add_node(&ast);
	i = 0;
	while (token[i])
	{
		if (!ft_strchr("<|>", token[i][0]))
			parse_arg(&ast, token[i], "C");
		else if (ft_strchr("<>", token[i][0]))
		{
			parse_arg(&ast, token[i + 1], token[i]);
			i++;
		}
		else if (token[i][0] == '|')
			parse_pipe(&ast);
		i++;
	}
	ft_mtx_free(token);
	return (ast);
}
