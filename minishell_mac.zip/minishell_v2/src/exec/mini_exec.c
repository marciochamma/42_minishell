/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mini_exec.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/05 17:36:04 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/11 21:28:35 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	exec1(void)
{
	t_env	*new;

	new = hashtable_create_node_type1("A");
	hashtable_mx(new, NULL, ADD);
	new = hashtable_create_node_type1("B=");
	hashtable_mx(new, NULL, ADD);
	new = hashtable_create_node_type2("C", "CCC");
	hashtable_mx(new, NULL, ADD);
	hashtable_mx(NULL, "B", DEL);
	hashtable_mx(NULL, "B", DEL);
	new = hashtable_create_node_type1("B=");
	hashtable_mx(new, NULL, ADD);
	new = hashtable_create_node_type1("B=");
	hashtable_mx(new, NULL, ADD);
}

void	exec2(t_list *ast)
{
	t_ctt	*ctt;
	t_arg	*temp;

	ctt = (t_ctt *)ast->content;
	temp = (t_arg *)ctt->arg;
	if (temp->str && !ft_strcmp(temp->str, "env"))
		env_call(ctt);
	if (temp->str && !ft_strcmp(temp->str, "export"))
		export_call(ctt);
	if (temp->str && !ft_strcmp(temp->str, "unset"))
		unset_call(ctt);
	if (temp->str && !ft_strcmp(temp->str, "pwd"))
		pwd_call();
	if (temp->str && !ft_strcmp(temp->str, "exit"))
		exit_call(ctt);
	if (temp->str && !ft_strcmp(temp->str, "echo"))
		echo_call(ctt);
	if (temp->str && !ft_strcmp(temp->str, "cd"))
		cd_call(ctt);
	printf("\n\n");
}
