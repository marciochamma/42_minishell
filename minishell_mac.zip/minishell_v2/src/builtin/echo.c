/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   echo.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/11 14:49:06 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/11 20:24:20 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	echo_call(t_ctt *ctt)
{
	t_arg	*arg;
	int		nline;

	nline = 1;
	arg = ((t_arg *)ctt->arg)->next;
	if (arg && !ft_strcmp(arg->str, "-n"))
	{
		nline = 0;
		arg = arg->next;
	}
	while (arg)
	{
		printf("%s", arg->str);
		if (arg->next)
			printf(" ");
		arg = arg->next;
	}
	if (nline)
		printf("%s", "\n");
}
