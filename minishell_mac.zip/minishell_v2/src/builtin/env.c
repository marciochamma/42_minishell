/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   env.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/03 15:20:37 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/10 16:22:57 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	env_print(void)
{
	char	**key;
	char	*value;
	char	*sign;
	int		i;

	key = hashtable_key_mtx();
	i = 0;
	while (key[i])
	{
		value = (hashtable_search(key[i]))->value;
		sign = (hashtable_search(key[i]))->sign;
		if (!ft_strcmp(sign, "="))
			printf("%s%s%s\n", key[i], sign, value);
		i++;
	}
	ft_mtx_free(key);
}

void	env_call(t_ctt *ctt)
{	
	t_arg	*arg;

	arg = (t_arg *)ctt->arg->next;
	if ((!arg || !ft_strcmp(arg->str, "") || arg->str[0] == '#'))
		env_print();
	else if (arg && ft_strcmp(arg->str, "") && arg->str[0] != '#')
		ft_printf("env: %s: No such file or directory\n", arg->str);
}
