/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   unset.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/10 16:14:22 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/10 21:43:42 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	unset_call(t_ctt *ctt)
{
	t_arg	*arg;
	int		befit;
	int		i;

	befit = 1;
	arg = (t_arg *)ctt->arg->next;
	while (arg)
	{
		i = 0;
		while (arg->str[i])
		{
			if (!(ft_isalnum(arg->str[i]) && arg->str[i] != '_'))
				befit = 0;
			i++;
		}
		if (befit == 1)
			hashtable_mx(NULL, arg->str, DEL);
		else
			printf("bash: unset: '%s': not a valid identifier", arg->str);
		arg = arg->next;
	}
}
