/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cd.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/11 20:24:33 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/12 11:23:28 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	cd_path(t_ctt *ctt)
{
	t_arg	*arg;
	t_env	*home;
	char	*path;

	arg = ctt->arg;
	home = hashtable_search("HOME");
	path = NULL;
	if (arg)
	{
		if (arg->next)
			path = arg->next->str;
		else if (!arg->next && home)
			path = home->value;
		if (path && chdir(path) == -1)
			printf("bash: cd: %s: No such file or directory", path);
		else if (!path)
			printf("bash: cd: HOME not set\n");
	}
}

void	cd_call(t_ctt *ctt)
{
	t_arg	*arg;
	t_env	*newpwd;
	t_env	*oldpwd;
	char	*cwd;

	arg = ((t_arg *)ctt->arg);
	if (arg->next && arg->next->next)
	{
		printf("bash: cd: %s: No such file or directory", arg->next->str);
		return ;
	}
	else if (arg || arg->next)
	{
		oldpwd = hashtable_create_node_type2("OLDPWD",
				hashtable_search("PWD")->value);
		hashtable_mx(oldpwd, NULL, ADD);
		cd_path(ctt);
		cwd = getcwd(NULL, 0);
		newpwd = hashtable_create_node_type2("PWD", cwd);
		hashtable_mx(newpwd, NULL, ADD);
		free(cwd);
	}
}
