/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mchamma <mchamma@student.42sp.org.br>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/01 13:05:33 by mchamma           #+#    #+#             */
/*   Updated: 2024/04/16 15:36:05 by mchamma          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include "libft.h"
# include <readline/readline.h>
# include <readline/history.h>
# include <stdio.h> // excluir

# define CMD 'C'
# define REDIR 'R'
# define HEREDOC 'H'

# define NOPIPE 'N'
# define LEFT 'L'
# define RIGHT 'R'

# define INIT 0
# define DEL 1
# define ADD 2
# define READ 3
# define FREE 4
# define PRINT 5

# define TABLE_SIZE 97

typedef struct s_env
{
	char			*key;
	char			*value;
	char			*sign;
	struct s_env	*next;
}	t_env;

typedef struct s_arg
{
	int				id;
	char			type;
	int				mode;
	int				fd;
	char			*str;
	struct s_arg	*next;
}	t_arg;

typedef struct s_ctt
{
	int				id;
	char			side;
	t_arg			*arg;
}	t_ctt;

// --------------------------------------- //

t_list	*parse_ast(char *str);

char	*arg_adjust(char *str);

void	free_ast_list(t_list *list);

void	print_ast(t_list *ast);

// --------------------------------------- //

char	**tknzer_t1(char *str);

char	**tknzer_t2(char *str);

char	**tknzer_t3(char *str);

void	print_token(char **token);

// --------------------------------------- //

void	forced_exit(char *str);

// --------------------------------------- //

void	hashtable_load(char **envp);

t_env	**hashtable_mx(t_env *new, char *key, int mode);

void	hashtable_init(t_env *hash[]);

void	hashtable_delete(t_env *hash[], char *key);

void	hashtable_insert_replace(t_env *hash[], t_env *new);

void	hashtable_print(t_env *hash[]);

void	hashtable_free_hash(t_env *hash[]);

void	hashtable_free_node(t_env *list);

void	hashtable_free_content(t_env *env);

t_env	*hashtable_create_node_type1(char *env);

t_env	*hashtable_create_node_type2(char *key, char *value);

t_env	*hashtable_search(char *key);

int		hashtable_count_content(void);

char	**hashtable_key_mtx(void);

// --------------------------------------- //

void	env_call(t_ctt *ctt);

void	export_call(t_ctt *ctt);

void	unset_call(t_ctt *ctt);

void	pwd_call(void);

int		exit_call(t_ctt *ctt);

void	echo_call(t_ctt *ctt);

void	cd_call(t_ctt *ctt);

// --------------------------------------- //

void	exec1(void);

void	exec2(t_list *ast);

#endif